#pragma once 

namespace timer {

static constexpr double kInterruptInterval_ms{16.384};

static constexpr uint32_t GetMaxCount(const double delay_time_ms) noexcept {
    return static_cast<uint32_t>(delay_time_ms / kInterruptInterval_ms);
}

namespace timer2 {

    static uint32_t max_count{};
    
    void Init(const double delay_time_ms) noexcept {
        asm("SEI");
        TCCR2B = (1 << CS20) | (1 << CS21) | (1 << CS22);
        OCR1A = 256;
        max_count = GetMaxCount(delay_time_ms); 
    }

    static inline bool IsEnabled(void) noexcept {
      return TIMSK2 & (1 << TOIE2);
    }

    static inline void Enable(void) noexcept {
        TIMSK2 = (1 << TOIE2);
    }

    static inline void Disable(void) noexcept {    
        TIMSK2 = 0x00;
    }

    static inline void Toggle(void) noexcept {
        if (IsEnabled()) {
            Disable();
        } else {
            Enable();
        }
    }  
} /* namespace timer1 */

/*
namespace timer2 {
  
    static uint32_t max_count{};
    
    void Init(const double delay_time_ms) noexcept {
        asm("SEI");
        TCCR2B = (1 << CS20) | (1 << CS21) | (1 << CS22);
        max_count = GetMaxCount(delay_time_ms);
    }

    static inline bool IsEnabled(void) noexcept {
      return TIMSK2 & (1 << TOIE2);
    }

    static inline void Enable(void) noexcept {
        TIMSK2 = (1 << TOIE2);
    }

    static inline void Disable(void) noexcept {    
        TIMSK2 = 0x00;
    }

    static inline void Toggle(void) noexcept {
        if (IsEnabled()) {
            Disable();
        } else {
            Enable();
        }
    }    
} *//* namespace timer2 */
} /* namespace timer */
