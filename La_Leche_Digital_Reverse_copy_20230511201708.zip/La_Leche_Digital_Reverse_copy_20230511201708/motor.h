#ifndef MOTOR_H_
#define MOTOR_H_

#include <stdbool.h>

#define MOTOR_FORWARD 5
#define MOTOR_REVERSE 6
#define MOTOR_START_MODULE 8

static bool MidSensorEnabled = false;
static bool MotorEnableForward = false;

static inline void motor_start(void);

static bool motor_forwards = false;

static inline void motor_init(void)
{
   MotorEnableForward = true;
   pinMode(MOTOR_FORWARD, OUTPUT);
   pinMode(MOTOR_REVERSE, OUTPUT);
   pinMode(MOTOR_START_MODULE, INPUT);
}

// Väntar på startsignalen via en loop.
static inline void motor_wait_for_start(void)
{
  while (digitalRead(MOTOR_START_MODULE) == 0); // Kanske ska vara en etta.
}

static inline double motor_pwm_value(const double duty_cycle)
{
  return duty_cycle * 255;
}

static inline void motor_forward(const double duty_cycle)
{
  if (digitalRead(MOTOR_START_MODULE) == 1)
  {
  analogWrite(MOTOR_FORWARD, motor_pwm_value(duty_cycle));
  digitalWrite(MOTOR_REVERSE, 0);
  motor_forwards = true;
  }
  else
  {
    analogWrite(MOTOR_FORWARD, motor_pwm_value(0.0));
  }

}

static inline void motor_reverse(const double duty_cycle)
{
  if(digitalRead(MOTOR_START_MODULE) == 1)
  {
  MidSensorEnabled = false;
  MotorEnableForward = false;
  digitalWrite(MOTOR_FORWARD, 0);
  analogWrite(MOTOR_REVERSE, motor_pwm_value(duty_cycle));
  motor_forwards = false;
  }
}

static inline bool motor_is_driving_forwards(void)
{
  return motor_forwards;
}

static inline void motor_toggle(const double duty_cycle)
{
  if (motor_is_driving_forwards())
  {
      motor_reverse(duty_cycle);
  }
  else
  {
    motor_forward(duty_cycle);
  }
}



#endif