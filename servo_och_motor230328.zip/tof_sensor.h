#ifndef TOF_SENSOR_H_
#define TOF_SENSOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <SharpIR.h>

struct tof_sensor			// strukt för impelentering av tof-sensorer (time of flight) som känner av avstånd mellan angivet min och max värde
{
	static constexpr int min_val = 10;			// sparar lägsta tillåtna värde
	static constexpr int max_val = 80;			// sparar högsta tillåtna värde
  static constexpr int model = 1080;
  SharpIR mySensor = SharpIR(0, model);	//sparar sensor värdet  stoppa in värde från sensor

   tof_sensor(void) { } 
};

static inline void tof_sensor_init(struct tof_sensor* self, const uint8_t pin)
{
	 self->mySensor = SharpIR(pin, self->model);
   return;
}

double tof_sensor_range(const struct tof_sensor* self)
{
	return self->max_val - self->min_val;
}

static inline int tof_sensor_read(struct tof_sensor* self)
{
   const int val = self->mySensor.distance();

   if (val > self->max_val)
	 {
	   return self->max_val;
	 }
	else if (val < self->min_val)
	{
		return self->min_val;
	}
  else
  {
     return val;
  }
}



#endif