#ifndef SERVO_H_
#define SERVO_H_

#include "pid.h"
#include "tof_sensor.h"

struct servo
{
	struct pid pid;
	struct tof_sensor left_sensor;
	struct tof_sensor right_sensor;

  servo(void) { }
};


// servo_init: initierar servomotor med angivna parametrar
// - self: referens till servomotorn
// - target_angle: målvinkel exempelvis 90 grader för rakt fram
// - output_min: lägsta tillåtna vinkel ( 0 = helt åt vänster )
// - output_max: högsta tillåtna vinkel ( 180 = helt åt höger )
// - input_min
// - input_max
// - kp
// - ki
// - kd

void servo_init(struct servo* self, const double target_angle, const double output_min, const double output_max, 
   const uint8_t left_sensor_pin, const uint8_t right_sensor_pin, const double kp = 1, const double ki = 0.01, const double kd = 0.1)
{
	pid_init(&self->pid, target_angle, output_min, output_max, kp, ki, kd);
	tof_sensor_init(&self->left_sensor, left_sensor_pin);
	tof_sensor_init(&self->right_sensor, right_sensor_pin);
}

static inline double servo_target(const struct servo* self)
{
	return self->pid.target;
}

static inline double servo_input(const struct servo* self)
{
	return self->pid.input;
}

static inline double servo_output(const struct servo* self)
{
	return self->pid.output;
}

static inline double servo_range(const struct servo* self)
{
	return tof_sensor_range(&self->left_sensor);
}

static inline double servo_input_difference(const struct servo* self)
{
	return tof_sensor_read(&self->left_sensor) - tof_sensor_read(&self->right_sensor);
}

static inline double servo_absolute_angle(const struct servo* self)
{
	return (servo_input_difference(self) + servo_range(self)) / 2.0;    // 0 - 1023
}

static inline double servo_mapped_input(const struct servo* self)
{
	const double normalized_input = servo_absolute_angle(self) / servo_range(self);  // 0 - 1
	return normalized_input * servo_target(self) * 2.0;
}
static inline void servo_print(const struct servo* self)
{
	printf("--------------------------------------------------------------------------------\n");
	printf("Target angle: %.1f degrees\n", servo_target(self));
	printf("Input Angle: %.1f Degrees\n", servo_mapped_input(self));
	printf("output Angle: %.1f Degrees\n", servo_output(self));

	const double relative_angle = servo_output(self) - servo_target(self);

	if (relative_angle > 0)
	{
		printf("Servo angled %.1f degrees to the right!\n", relative_angle);
	}
	else if (relative_angle < 0)
	{
		printf("Servo angled %.1f degrees to the left!\n", -relative_angle);
	}
	else
	{
		printf("Servo angled right at target!\n");
	}

	printf("--------------------------------------------------------------------------------\n\n");
	return;
}

static inline void servo_run(struct servo* self)
{
	printf("enter value for left TOF sensor:\n");
	tof_sensor_read(&self->left_sensor);
	printf("enter value for right TOF sensor\n");
	tof_sensor_read(&self->right_sensor);

	pid_regulate(&self->pid, servo_mapped_input(self));
	servo_print(self);
}
#endif