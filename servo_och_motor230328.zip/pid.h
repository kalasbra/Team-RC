#ifndef PID_H_
#define PID_H_

#include <stdio.h>

struct pid
{
	double target;				//Target / Börvärde, det vi siktar på
	double output;				// ärvärde, aktuell utsignal
	double input;				// aktuell insignal (sparas för utskrift)
	double kp;					//förstärkningsfaktor för den proportionella delen
	double ki;					// Förstärkningsfaktor för den itegrerande delen)
	double kd;					// förstärkningsfaktor för den deriverande delen	
	double last_error;			// föregårende fel
	double delta;				// derivatan av aktuellt fel (nuvarande fel - föregående fel)
	double integrate;			// integralen av felet
	double output_min;			// lägsta möjliga utsignal
	double output_max;			// högsta möjliga utsignal
};

// pid_init: initierar ny PID-regulator med angivna parametrar
// - self referens till PID-regulatorn
// - target - börvärde
// - output_min : lägsta tillåtna utsignal
// - output_max : högsta tillåtna utsignal
// - kp : förstärkningsfaktor för den proportionella delen
// - ki : förstärkningsfaktor för den integrerande delen
// - kd: förstärkningsfaktor för den deriverande delen

void pid_init(struct pid* self, const double target, const double output_min, const double output_max, const double kp, const double ki, const double kd);





// pid_regulate: Reglerar PID-regulatorns utsignal efter angiven ny insignal.

void pid_regulate(struct pid* self, const double new_input);

void pid_print(const struct pid* self, FILE* ostream);

#endif
 