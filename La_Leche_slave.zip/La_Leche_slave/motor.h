/*****************************************************************************************
*
* motor.h : Innehåller drivrutiner för DC motorn och start-modul. Pinsen är definerade
*           med namn för att underlätta användandet. Funktionerna handlar enbart om drift,
*           Körning framåt, bakåt, boost för backe och backning åt respektive riktning
*
******************************************************************************************/






#ifndef MOTOR_H_
#define MOTOR_H_

#include <stdbool.h>
#include <Servo.h>
#include <Arduino.h>

#define MOTOR_FORWARD 5   //Pin för drift framåt kopplad till In1 på H-brygga
#define MOTOR_REVERSE 6   //Pin för drift bakåt kopplad till In2 på H-brygga
#define BOOST 7           //Pin för avläsning om boost skall aktiveras
#define MOTOR_START_MODULE 8  //Pin för avläsning av start-modul
#define REVERSE_RIGHT 11      //Pin för avläsning om Höger-backning skall påbörjas
#define REVERSE_LEFT 10       //Pin för avläsning om Vänster-backning skall påbörjas



static inline void motor_forward(const double duty_cycle);

static inline void boost(void);

Servo myservo;


static inline void motor_init(void)     // Initiering av Pins för drift och start-modul
{
   pinMode(MOTOR_FORWARD, OUTPUT);
   pinMode(MOTOR_REVERSE, OUTPUT);
   pinMode(MOTOR_START_MODULE, INPUT);
}

static inline void boost(void)      // Boost-funktion där hjulen ställs rakt sedan kör 100% drift
{
     myservo.write(80);
     motor_forward(1);
   
}

static inline void motor_wait_for_start(void) // Funktionen användes aldrig men syftar till vad som skall ske medans start-modulen inte är högställd
{
  while (digitalRead(MOTOR_START_MODULE) == 0);
}

static inline double motor_pwm_value(const double duty_cycle)   // Omvandling av värde mellan 0 - 1 till värde mellan 0 - 255 för korrekt PWM matning
{
  return duty_cycle * 255;
}

static inline void motor_forward(const double duty_cycle)   // Drift framåt, enbart medan signal från start-modul = hög
{
  if (digitalRead(MOTOR_START_MODULE) == 1)
  {
  analogWrite(MOTOR_FORWARD, motor_pwm_value(duty_cycle));
  digitalWrite(MOTOR_REVERSE, 0);
  }
  else
  {
    analogWrite(MOTOR_FORWARD, motor_pwm_value(0.0));
  }

}

static inline void motor_reverse(const double duty_cycle)  // Drift bakåt/backning, enbart medan signal från start-modul = hög
{
  if(digitalRead(MOTOR_START_MODULE) == 1)
  {
  digitalWrite(MOTOR_FORWARD, 0);
  analogWrite(MOTOR_REVERSE, motor_pwm_value(duty_cycle));
  }
}


static inline void Reverse_left(void)   // Svänger hjulen åt vänster för att sedan backa i 50% drift i 1 sekund 
{
  myservo.write(55);
  motor_reverse(0.5);
  delay(1000);
}

static inline void Reverse_right(void)    // Svänger hjulen åt höger för att sedan backa i 50% drift i 1 sekund
{
  myservo.write(105);
  motor_reverse(0.5);
  delay(1000);
}







#endif