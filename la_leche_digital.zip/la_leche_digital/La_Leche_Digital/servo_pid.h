

#ifndef SERVO_PID_H_
#define SERVO_PID_H_

#include "pid.h"
#include "tof_sensor.h"
#include <Arduino.h>

struct servo_pid
{
	struct pid pid;
	struct tof_sensor left_sensor;
	struct tof_sensor right_sensor;
  

  servo_pid(void) { }
};


// servo_init: initierar servomotor med angivna parametrar
// - self: referens till servomotorn
// - target_angle: målvinkel exempelvis 90 grader för rakt fram
// - output_min: lägsta tillåtna vinkel ( 0 = helt åt vänster )
// - output_max: högsta tillåtna vinkel ( 180 = helt åt höger )
// - input_min
// - input_max
// - kp
// - ki
// - kd

void servo_init(struct servo_pid* self, 
                const double target_angle, const double output_min, const double output_max, 
                const uint8_t left_sensor_pin, const uint8_t right_sensor_pin, 
                const double kp = 2, const double ki = 0, const double kd = 2)
{
	pid_init(&self->pid, target_angle, output_min, output_max, kp, ki, kd);
	tof_sensor_init(&self->left_sensor, left_sensor_pin);
	tof_sensor_init(&self->right_sensor, right_sensor_pin);
}

static inline double servo_target(const struct servo_pid* self)
{
	return self->pid.target;
}

static inline double servo_input(const struct servo_pid* self)
{
	return self->pid.input;
}

static inline double servo_output(const struct servo_pid* self) // Vinkel
{
	return self->pid.output;
}

static inline double servo_normalized_output(const struct servo_pid* self) // 0 - 1 (0.5 = mitten)
{
   return self->pid.output / (self->pid.output_max - self->pid.output_min); 
}

static inline double servo_pwm_output(const struct servo_pid* self)
{
  return servo_normalized_output(self) * 255;
}

static inline double servo_range(const struct servo_pid* self)
{
	return tof_sensor_range(&self->left_sensor);
}

static inline double servo_input_difference(struct servo_pid* self)
{
	return tof_sensor_read(&self->left_sensor) - tof_sensor_read(&self->right_sensor);
}

static inline double servo_absolute_angle(struct servo_pid* self)
{
	return (servo_input_difference(self) + servo_range(self)) / 2.0;    // 0 - 1023
}

static inline double servo_normalized_input(struct servo_pid* self) // Returnerar input som flyttal mellan 0 - 1.
{
   return servo_absolute_angle(self) / servo_range(self);
}

static inline double servo_mapped_input(struct servo_pid* self) // Returnerar input som flyttal mellan 0 - 180 (vinkel).
{
	return servo_normalized_input(self) * servo_target(self) * 2.0;
}


static inline void servo_run(struct servo_pid* self)
{
	tof_sensor_read(&self->left_sensor);
	tof_sensor_read(&self->right_sensor);
	pid_regulate(&self->pid, servo_mapped_input(self)); 
  //servo_set_pwm_output(self);
}
#endif