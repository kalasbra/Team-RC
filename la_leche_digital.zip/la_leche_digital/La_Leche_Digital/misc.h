#ifndef MISC_H_
#define MISC_H_

#define F_CPU 16000000UL

#include <util/delay.h>

static inline void delay_us(const uint16_t delay_time_us)
{
  for (uint16_t i = 0; i < delay_time_us; ++i)
  {
    _delay_us(1);
  }
  return;
}

static inline void delay_ms(const uint16_t delay_time_ms)
{
  for (uint16_t i = 0; i < delay_time_ms; ++i)
  {
    _delay_ms(1);
  }
  return;
}

#endif /* MISC_H_ */