/*************************************************************************************************
* array.hpp: Inehåller arrayer och funktioner för dessa att lägga till i index och hämta ut 
*            snitt-värden för respektive array. Implementerade för att användas vid kontroll
*            av backning.
*
**************************************************************************************************/

#pragma once 

#include <stdint.h>

template <typename T, size_t size>             // Template/objekt för att skapa arrayer efter behov samt funktioner för beräkning av snitt, addering av index, rensning av data osv.
class Array {
    static_assert(size > 0, "Array size cannot be set to 0!");
  public:
    Array(void) = default;

    T& operator[] (const size_t index) noexcept {
        return data_[index];
    }

    const T& operator[] (const size_t index) const noexcept {
        return data_[index];
    }

    size_t Size(void) const {
        return size;
    }

    T* begin(void) noexcept {
        return data_;
    }

    const T* begin(void) const noexcept {
        return data_;
    }

    T* end (void) noexcept {
        return data_ + size;;
    }

    const T* end(void) const noexcept {
        return data_ + size;
    }

    void Clear(void) noexcept {
        for (auto& i : *this) {
            i = 0;
        }
    }

    void AddValue(const T& value) noexcept {
        data_[next_++] = value;
        if (next_ >= size) {
            next_ = 0;
        }
    }

    T GetSum(void) const noexcept {
        T sum{};
        for (auto& i : *this) {
            sum += i;
        }
        return sum;
    }

    double GetAverage(void) const noexcept {
        return GetSum() / static_cast<double>(size);
    }
    

  private:
    T data_[size]{};
    size_t next_{};
};