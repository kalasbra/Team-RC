/************************************************************************************************
* servo_pid.h : Innehåller nödvändiga funktioner för styrning samt kontroll av fordonet.
*               Bool variabler implementerades för att undvika krockar där olika funktioner
*               avbröt pågående körning. T ex att boost-funktionen aktiverades under backning.
*
************************************************************************************************/


#ifndef SERVO_PID_H_
#define SERVO_PID_H_

#include "pid.h"
#include <Arduino.h>
#include "timer.hpp"
#include "array.hpp"

#define REVERSE_RIGHT 11      //Pin för skrivning till slav-enhet
#define REVERSE_LEFT 10       //Pin för skrivning till slav-enhet
#define BOOST 7               //Pin för skrivning till slav-enhet

static bool MotorEnableForward = false;   // variabel för att se till att boost inte aktiverades under backning

struct servo_pid
{
	struct pid pid;
	
  

  servo_pid(void) { }
};

static inline void reset(void);


// servo_init: initierar servomotor med angivna parametrar
// - self: referens till servomotorn
// - target_angle: målvinkel exempelvis 90 grader för rakt fram
// - output_min: lägsta tillåtna vinkel ( 0 = helt åt vänster )
// - output_max: högsta tillåtna vinkel ( 180 = helt åt höger )
// - input_min
// - input_max
// - kp
// - ki
// - kd

void servo_init(struct servo_pid* self, 
                const double target_angle, const double output_min, const double output_max, 
                const double kp = 1, const double ki = 0.0, const double kd = 0.1)    // Initierar servo-structen med startvärden där min/max utslag ingår, samt hur står påverkan PID har
{
	pid_init(&self->pid, target_angle, output_min, output_max, kp, ki, kd);
}

static inline double servo_target(const struct servo_pid* self)  // Returnerar börvärde
{
	return self->pid.target;
}

static inline double servo_input(const struct servo_pid* self) //Returnerar ny input från sensorer fast subtraherad från varandra
{
	return self->pid.input;
}

static inline double servo_output(const struct servo_pid* self) // Returnerar den output vi vill skriva till servon
{
	return self->pid.output;
}

static inline double servo_normalized_output(const struct servo_pid* self) // 0 - 1 (0.5 = mitten) // Returnerar servo output delat med servo-range (som det borde kallats)
{
   return self->pid.output / (self->pid.output_max - self->pid.output_min); 
}

static inline double servo_range(void)  // Returnerar sensorernas läsbara spann
{
	return 3960;
}

static inline double servo_input_difference(struct servo_pid* self) // Returnerar vänster sensor värde minus höger sensor värde
{
	return distance_left() - distance_right();
}

static inline double servo_absolute_angle(struct servo_pid* self)   // Returnerar skillnad i mätvärden plus det maximala spann sensorerna kan läsa dividerat med 2
{
	return (servo_input_difference(self) + servo_range()) / 2.0;    
}

static inline double servo_normalized_input(struct servo_pid* self) // Returnerar input som flyttal mellan 0 - 1
{
   return servo_absolute_angle(self) / servo_range();
}

static inline double servo_mapped_input(struct servo_pid* self) // Returnerar input som flyttal mellan 0 - 180 (vinkel).
{
    return servo_normalized_input(self) * 180;
}


static inline void servo_run(struct servo_pid* self)  // Läser avstånd och kallar på beräkning av servo-output
{
  distance_left();
  distance_right();
	pid_regulate(&self->pid, servo_mapped_input(self)); 
}

static inline void motor_uphill(struct servo_pid* self)   // Läser avstånd på mitten sensorn och aktiverar boost om avstånd hamnar inom rätt spann
{
  
    int mid_val = distance_mid();
    if(mid_val > 70 && mid_val < 170)
    {
      MidSensorEnabled = false;
      digitalWrite(BOOST, HIGH);
      return;
    }
    else if(mid_val > 170)
    {
      digitalWrite(BOOST, LOW);
      return;
    }
    else
    {
      return;
    }
    
}

static inline uint16_t left_sensor_read(struct servo_pid* self) // Funktion enbart skapad för att underlätta matningen av värden till arrayen för backfunktion
{
  uint16_t val = distance_left();
  return val;
}

static inline uint16_t right_sensor_read(void)                  // Funktion enbart skapad för att underlätta matningen av värden till arrayen för backfunktion
{
  uint16_t val = distance_right();
  return val;
}

static inline void ReverseCheck(void)               // Funktion som mäter avstånd på mitten sensorn och kallar på reset som i sin tur jämför värden i back-arrayen
{
  uint16_t val = distance_mid();
  if(val < 50 && ReverseEnabled == 1)
  {
    reset();
  }
}

static inline double get_position(struct servo_pid* self) // Funktion som kör pid-regleringen och returnerar den output pid-regleringen beräknar
{
  servo_run(self);
  return servo_output(self);
}

static inline void reset(void)      // Funktion som kallar på jämförelse av 1 array där index 0 - 1 subtraheras från idex 2 - 3 för att förstå om bilen är i behov av backning
{                                   // Om bilen är i behov av backning åt vänster högställs en pin, om bilen är i behov av backning åt höger högställs en annan
  uint8_t difference = Delta();
  if(difference < 30)
  {
    uint8_t left = LeftAverage();
    uint8_t right = RightAverage();
    if(left < right)
    {
      MotorEnableForward = false;
      MidSensorEnabled = false;
      digitalWrite(REVERSE_LEFT, HIGH);
      digitalWrite(REVERSE_RIGHT, LOW);
      MotorEnableForward = true;
      MidSensorEnabled = true;
    }
    else if(left > right)
    {
      MotorEnableForward = false;
      MidSensorEnabled = false;
      digitalWrite(REVERSE_LEFT, LOW);
      digitalWrite(REVERSE_RIGHT, HIGH);
      MotorEnableForward = true;
      MidSensorEnabled = true;
    }
    
  }
  else
  {
    digitalWrite(REVERSE_LEFT, LOW);
    digitalWrite(REVERSE_RIGHT, LOW);
    return;
  }
}
#endif