/**************************************************************************************
* timer.hpp : Innehåller templates för timerkretsar samt funktioner för att
*             fylla arrayer vid olika tidpunkter för beräkning av backning
*
*
***************************************************************************************/


#pragma once 


#include "array.hpp"


static inline void timer_init(void);

static inline double distance_left(void);
static inline double distance_right(void);
static inline double distance_mid(void);

static volatile bool MidSensorEnabled = false;
static volatile bool ReverseEnabled = false;

namespace timer {

static constexpr double kInterruptInterval_ms{16.384};

static constexpr uint32_t GetMaxCount(const double delay_time_ms) noexcept {
    return static_cast<uint32_t>(delay_time_ms / kInterruptInterval_ms);
}

namespace timer2 {

    static uint32_t max_count{};
    
    void Init(const double delay_time_ms) noexcept {
        asm("SEI");
        TCCR2B = (1 << CS20) | (1 << CS21) | (1 << CS22);
        max_count = GetMaxCount(delay_time_ms); 
    }

    static inline bool IsEnabled(void) noexcept {
      return TIMSK2 & (1 << TOIE2);
    }

    static inline void Enable(void) noexcept {
        TIMSK2 = (1 << TOIE2);
    }

    static inline void Disable(void) noexcept {    
        TIMSK2 = 0x00;
    }

    static inline void Toggle(void) noexcept {
        if (IsEnabled()) {
            Disable();
        } else {
            Enable();
        }
    }  
} /* namespace timer1 */


namespace timer0 {
  
    static uint32_t max_count{};
    
    void Init(const double delay_time_ms) noexcept {
        asm("SEI");
        TCCR0B = (1 << CS00) | (1 << CS01) | (1 << CS02);
        max_count = GetMaxCount(delay_time_ms);
    }

    static inline bool IsEnabled(void) noexcept {
      return TIMSK0 & (1 << TOIE0);
    }

    static inline void Enable(void) noexcept {
        TIMSK0 = (1 << TOIE0);
    }

    static inline void Disable(void) noexcept {    
        TIMSK0 = 0x00;
    }

    static inline void Toggle(void) noexcept {
        if (IsEnabled()) {
            Disable();
        } else {
            Enable();
        }
    }    
} /* namespace timer2 */
} /* namespace timer */


  // create servo object to control a servo
// twelve servo objects can be created on most boards



Array<uint32_t, 40> buffer; /* Buffer för att lagra lästa värden). */
Array<uint32_t, 40> buffer2;
Array<uint32_t, 4> buffer3;

static constexpr uint8_t kBufferPrescaler{7}; /* Skriver till buffern sju gånger innan Timer 1 löper ut. */

static inline bool TimeToUpdateBuffer(const volatile uint32_t counter) // Händelse när timern räknat upp till visst antal - i timern läggs de funktioner som ska anropas vid denna tidpunkt under denna funktion
{
    return counter > 0 && (counter % (timer::timer2::max_count / 7) == 0) ? true : false;
}

static inline bool TimeToCheckReset(const volatile uint32_t counter)  // Händelse när timern räknat upp till visst antal - i timern läggs de funktioner som ska anropas vid denna tidpunkt under denna funktion
{
  return counter > 0 && (counter % (timer::timer2::max_count / 2) == 0) ? true : false;
}

template <typename T>
static inline T GetLeftSensorAverage(void) noexcept     // Returnerar average för vänster sensors array
{
    return static_cast<T>(buffer.GetAverage());
}

template <typename T>
static inline T GetRightSensorAverage(void) noexcept    // Returnerar average för höger sensors array
{
    return static_cast<T>(buffer2.GetAverage());
}



template <typename T>
static inline T GetDistanceDelta(void) noexcept   // Returnerar skillnaden mellan mätning på index 0 och 1 med mätning på index 2 och 3
{
  return static_cast<T>((buffer3[0] + buffer3[1]) - (buffer3[2] + buffer3[3]));
}



ISR (TIMER2_OVF_vect)   // service routine för timer 2, lägger till värden i 3 olika arrayer samt återställer bool-variabler
{
    static volatile uint32_t counter{};
    
         
    if (++counter >= timer::timer0::max_count) 
    {
        counter = 0;
        ReverseEnabled = true;
        if (MidSensorEnabled == false)
        {
          MidSensorEnabled = true;
        }
    }

    if (TimeToUpdateBuffer(counter)) 
    {
        buffer.AddValue(distance_left()); // adderar värde till vänster array
        buffer2.AddValue(distance_right()); // adderar värde till höger array
    }

    if (TimeToCheckReset(counter))
    {
      buffer3.AddValue(distance_left());    // adderar värde till arrayen som talar om för oss om vi behöver backa
      buffer3.AddValue(distance_right());   // adderar värde till arrayen som talar om för oss om vi behöver backa
      
    }
}

static inline uint16_t Delta(void)   // Hämtar skillnaden mellan index 0 - 1 och 2 - 3
{
  return GetDistanceDelta<uint16_t>();
}

static inline uint16_t LeftAverage(void) // returnerar vänster snittvärde
{
  return GetLeftSensorAverage<uint16_t>();
}

static inline uint16_t RightAverage(void) // returnerar höger snittvärde
{
  return GetRightSensorAverage<uint16_t>();
}

static inline void timer_init(void)  // Initierar timer
{
  timer::timer2::Init(3000); /* Löper ut efter 3 sekunder. */
  timer::timer2::Enable();
}